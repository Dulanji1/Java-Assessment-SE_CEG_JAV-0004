package com.example.scheduling.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
